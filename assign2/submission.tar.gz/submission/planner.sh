#!/bin/bash

python planner.py "$@"