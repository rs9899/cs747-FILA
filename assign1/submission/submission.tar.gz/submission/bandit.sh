#!/bin/bash

python bandit.py "$@"